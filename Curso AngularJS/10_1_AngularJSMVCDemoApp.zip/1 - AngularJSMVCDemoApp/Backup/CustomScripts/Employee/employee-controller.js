﻿mainApp.controller("employeeController", ['$scope', 'employeeService', function ($scope, employeeService) {
    $scope.employees = employeeService.employees;
  }
]);