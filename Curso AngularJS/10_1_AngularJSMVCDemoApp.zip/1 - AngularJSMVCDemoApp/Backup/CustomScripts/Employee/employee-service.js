﻿mainApp.factory('MathService', function () {
    var factory = {};
    factory.GetEmployees = function () {
        return 
    }
    return factory;
});
