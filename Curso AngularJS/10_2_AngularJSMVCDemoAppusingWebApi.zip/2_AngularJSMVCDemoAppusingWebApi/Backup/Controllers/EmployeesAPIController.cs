﻿using AngularJSMVCDemoAPP.BO;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AngularJSMVCDemoApp.Controllers
{
    public class EmployeesController : ApiController
    {
        EmployeeBO empBO = new EmployeeBO();
        // GET api/employeeapi
        public EmployeesController()
        {
            //Following is needed if the Employee properties are in camel case.
            //Ideally it should be written in Global.asax
            var json = GlobalConfiguration.Configuration.Formatters.JsonFormatter;
            json.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver();
            json.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore;
        }
        public IEnumerable Get()
        {
            return empBO.GetAllEmployees();
        }  

        // GET api/employeeapi/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/employeeapi
        public void Post([FromBody]string value)
        {
        }

        // PUT api/employeeapi/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/employeeapi/5
        public void Delete(int id)
        {
        }
    }
}
