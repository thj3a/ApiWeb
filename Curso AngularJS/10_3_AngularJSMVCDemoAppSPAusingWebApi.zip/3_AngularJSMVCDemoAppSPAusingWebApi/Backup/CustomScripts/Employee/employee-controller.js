﻿mainApp.controller("employeeController", ['$scope', 'employeeService', function ($scope, employeeService) {
    employeeService.get().then(function (employees) {
        $scope.employees = employees
    })
  }
]); 